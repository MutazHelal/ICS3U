package wayne.gretzky;

/*
 *Created by M.Helal
 *On Spetember 30
 *to store string and integer in memory locations then print from locations
 */
public class WayneGretzky {

    public static void main(String[] args) {
        int JerseyNumber;
        String FullName;
        JerseyNumber = 99;
        FullName = ("Wayne Gretzky");
        System.out.println(FullName + " is number " + JerseyNumber); // Print from memory locations 
    }

}
